package ru.galacticaxe;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import ru.galacticaxe.items.ItemGalacticAxe;

@Mod(modid = GalacticAxeMod.MODID, name = GalacticAxeMod.NAME,
     version = GalacticAxeMod.VERSION, acceptedMinecraftVersions = "1.12.2")
public class GalacticAxeMod {
    public static final String MODID = "galacticaxe";
    public static final String NAME = "Galactic Axe";
    public static final String VERSION = "1.0";

    public static Item galacticAxe;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // harvestLevel 4 (кобальт уровня), 10000 прочности,
        // эффективность 12.0, урон 7776.0 + 1.0 базовый = 7777
        Item.ToolMaterial GALACTIC = EnumHelper.addToolMaterial(
                "GALACTIC", 4, 10000, 12.0F, 7776.0F, 30);

        galacticAxe = new ItemGalacticAxe(GALACTIC)
                .setRegistryName("galactic_axe")
                .setUnlocalizedName("galactic_axe")
                .setCreativeTab(CreativeTabs.COMBAT);

        ForgeRegistries.ITEMS.register(galacticAxe);

        // Регистрация модели (клиент)
        ModelLoader.setCustomModelResourceLocation(galacticAxe, 0,
                new ModelResourceLocation(galacticAxe.getRegistryName(), "inventory"));
    }
}
