package ru.galacticaxe.items;

import net.minecraft.item.ItemAxe;

public class ItemGalacticAxe extends ItemAxe {
    public ItemGalacticAxe(ToolMaterial material) {
        // В ItemAxe переданный урон прибавляется к базовым 1.0, итого 7777
        super(material, 7776.0F, -3.0F);
    }
}
